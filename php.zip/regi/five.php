<?php
header("Content-Type:text/html; charset=utf-8");
$link=mysqli_connect("localhost", "root", "c194xo4", "car");

$sql="SELECT * FROM orderr WHERE offer_ID is null Limit 3";     //選擇所有rent欄位
$result=mysqli_query($link, $sql);      //執行SQL查詢
while($row=mysqli_fetch_assoc($result)){
	?>
	<li>委託編號</li>
	<li>車型等級需求</li>
	<li>租用起始日</li>
	<li>可租用天數</li>
	<li>價格</li>
	<li>#<?php echo $row["ID"]; ?></li>
	<li><?php echo $row["seat"]; ?>人坐</li>
	<li><?php echo $row["start_date"]; ?></li>
	<li><?php echo $row["days"]; ?>天</li>
	<li><?php echo $row["price"]; ?>元</li>

<?php
}

$sql2="SELECT orderr.ID, orderr.seat, orderr.start_date, orderr.days, orderr.price FROM orderr, car WHERE orderr.rent_ID is null and orderr.car_ID = car.ID Limit 3";     //選擇所有rent欄位
$result=mysqli_query($link, $sql2);      //執行SQL查詢
while($row2=mysqli_fetch_assoc($result)){
?>
	<li>委託編號</li>
	<li>車廠品牌</li>
	<li>租用起始日</li>
	<li>可租用天數</li>
	<li>價格</li>
	<li>#<?php echo $row2["ID"]; ?></li>
	<li><?php echo $row2["seat"]; ?>人坐</li>
	<li><?php echo $row2["start_date"]; ?></li>
	<li><?php echo $row2["days"]; ?>天</li>
	<li><?php echo $row2["price"]; ?>元</li>
<?php
}
?>
