<?php
include('config.php');
error_reporting(E_ALL ^ E_DEPRECATED);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/read_pm.css">
    <link rel="stylesheet" href="../CSS/all.css">
    <title>9453學生租車平台</title>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type='text/javascript'>
        $(function(){
            var $menu = $('.menu'),
                _top = $menu.offset().top;
         
            var $win = $(window).scroll(function(){
                if($win.scrollTop() >= _top){
                    if($menu.css('position')!='fixed'){
                        $menu.css({
                            position: 'fixed',
                            top: 0 
                        });
                    }
                }else{
                    $menu.css({
                        position: 'absolute',
                        top: 150
                    });
                }
            });
        });
    </script>
</head>
    <body>
        <div class="wrap">
            <div class="header">
                <a href="index.php"><h1><img src="../photo/icon.png" width="320px"></h1></a>
                <div class="user">
                    <?php 
                    if(isset($_SESSION['username'])) //2016.5.21
                    {
                    ?>
                    <p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
                    <a href="../logout.php"><button class="logout">登出</a>
                    <?php
                    }
                    else
                    {
                    ?>
                        <script>
                            alert("請先登入會員");
                            location.replace("../login.php");
                        </script>
                    <?php
                    }
                    ?>
                </div>
                <div class="clear"></div>
            </div>
            <div class="menu">
                <ul>
                    <a href="../index.php"><li>回首頁</li></a>
					<a href="../supply_showdata.php"><li>找車子</li></a>
					<a href="../showdata.php"><li>找委託</li></a>
					<a href="../supply.php"><li>我要出租!</li></a>
					<a href="../rent.php"><li>我要委託!</li></a>
					<div class="member"><a href="../member.php"><img src="../photo/boss.png" style="width: 35px;">會員專區</a></div>
                </ul>
            </div>

			<?php
			if(isset($_GET['id']))
			{
				$id = intval($_GET['id']);
				//We get the title and the narators of the discussion
				$req1 = mysql_query('SELECT title, user1, user2 from pm where id="'.$id.'" and id2="1"');
				$dn1 = mysql_fetch_array($req1);
				//We check if the discussion exists
				if(mysql_num_rows($req1)==1)
				{
				//We check if the user have the right to read this discussion
					if($dn1['user1']==$_SESSION['username'] or $dn1['user2']==$_SESSION['username'])
					{
					//The discussion will be placed in read messages
						if($dn1['user1']==$_SESSION['username'])
						{
							mysql_query('UPDATE pm set user1read="yes" where id="'.$id.'" and id2="1"');
							$user_partic = 2;
						}
						else
						{
							mysql_query('UPDATE pm set user2read="yes" where id="'.$id.'" and id2="1"');
							$user_partic = 1;
						}
						//We get the list of the messages
						$req2 = mysql_query('SELECT `timestamp`, `message`, user.`username`, user.`id` as userid from `pm`, `user` where pm.`id`="'.$id.'" and user.`username`=pm.`user1` order by pm.`id2`');
						//We check if the form has been sent
						if(isset($_POST['message']) and $_POST['message']!='')
						{
							$message = $_POST['message'];
							//We remove slashes depending on the configuration
							if(get_magic_quotes_gpc())
							{
								$message = stripslashes($message);
							}
							//We protect the variables
							$message = mysql_real_escape_string(nl2br(htmlentities($message, ENT_QUOTES, 'UTF-8')));
							//We send the message and we change the status of the discussion to unread for the recipient
							//INSERT into pm (id, id2, user1, user2, message, timestamp, user1read, user2read)values("'.$id.'", "'.(intval(mysql_num_rows($req2))+1).'", "'.$dn1['user2'].'", "'.$_SESSION['username'].'",  "'.$message.'", "'.time().'", "yes", "yes")'))
							if(mysql_query('INSERT into pm (id, id2, title, user1, user2, message, timestamp, user1read, user2read)values("'.$id.'", "'.(intval(mysql_num_rows($req2))+1).'", "", "'.$_SESSION['username'].'", "", "'.$message.'", "'.time().'", "", )') and mysql_query('UPDATE pm set user'.$user_partic.'read="yes" where id="'.$id.'" and id2="1"'))
							{				
						?>
								<div class="message">郵件已寄出!<br />
								<a href="read_pm.php?id=<?php echo $id; ?>">回到信件</a></div>
						<?php
							}
							else
							{
						?>
								<div class="message">寄送時發生問題!<br />
								<a href="read_pm.php?id=<?php echo $id; ?>">回到信件</a></div>
						<?php
							}
						}
						else
						{
						//We display the messages
						?>
							<div class="content">
								<div class="title"><h2>信件內容/Mail Content</h2></div>
				                <div class="member_bar">
				                    <div class="title_2"><h3>會員功能</h3></div>
				                    <a href="../orderandrent.php"><li>租借紀錄</li></a>
				                    <a href="../update.php"><li>更新帳號資訊</li></a>
				                    <a href="users.php"><li>會員名單</li></a>
				                    <a href="../pm/index.php"><li>站內信</li></a>
				                </div>
								
								<div class="mail_area">
									<div class="title_3"><h4>標題：<?php echo $dn1['title']; ?></h4></div>

									<?php
									while($dn2 = mysql_fetch_array($req2))
									{
									?>	<li><span class="subtitle">寄件者</span></li>
									    <li><?php echo $dn2['username']; ?></li>
									    <div class="clear"></div>
									    <li><span class="subtitle">信件內容</span></li>
									    <li><?php echo $dn2['message']; ?></li>
									    <div class="clear"></div>
									    <li><span class="subtitle">發送時間</span></li>
									    <li><?php echo date('m/d/Y H:i:s' ,$dn2['timestamp']); ?></li>
									    <div class="clear"></div>
									<?php
									}
									//We display the reply form
									?>
									<?php
									if (($_SESSION['username']) != $dn1['user1']) {
									?>
										<a href="new_pm.php?recip=<?php echo $dn1['user1'] ?>"><button class = "mail_btn">回覆信件</a>
									<?php
									}
									?>
								</div>
							</div>
					<?php
						}
					}
					else
					{
						echo '<div class="message">你沒有權限查看此頁面!.</div>';
					}
				}
				else
				{
					echo '<div class="message">此信件不存在!</div>';
				}
			}
			?>
			<footer>
                <p>9453學生租車平台</p>
                <p>© 2017 All rights reserved.</p>
                <p>NUKIM 2017 PHP</p>
            </footer>	
		</div>
	</body>
</html>