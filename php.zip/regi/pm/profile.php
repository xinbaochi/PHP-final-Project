<?php
	include('config.php');
	error_reporting(E_ALL ^ E_DEPRECATED); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="../CSS/profile.css">
	<link rel="stylesheet" href="../CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="../photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<script>
							alert("請先登入會員");
							location.replace("../login.php");
					</script>	
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
		</div>
		<div class="menu">
			<ul>
				<a href="../index.php"><li>回首頁</li></a>
				<a href="../supply_showdata.php"><li>找車子</li></a>
				<a href="../showdata.php"><li>找委託</li></a>
				<a href="../supply.php"><li>我要出租!</li></a>
				<a href="../rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="../member.php"><img src="../photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class="content">
			<div class="title"><h2>會員資料/Member Profile</h2></div>
			<div class="member_bar">
				<div class="title_2"><h3>會員功能</h3></div>
				<a href="../orderandrent.php"><li>租借紀錄</li></a>
				<a href="../update.php"><li>更新帳號資訊</li></a>
				<a href="users.php"><li>會員名單</li></a>
				<a href="index.php"><li>站內信</li></a>
			</div>
			<?php
			if(isset($_GET['id']))
			{
				//$id = intval($_GET['id']);
				//We check if the user exists
				$dn = mysql_query('SELECT `username`, `email`, `userphone`,  `grade`, `bank`, `bankaccount` FROM `user` WHERE `id`="'.$_GET['id'].'"');
				if(mysql_num_rows($dn)>0)
				{
					$dnn = mysql_fetch_array($dn);
					//We display the user datas
			?>
					<div class="profile">
			    	<li>會員姓名：<?php echo htmlentities($dnn['username'], ENT_QUOTES, 'UTF-8'); ?></li>
			    	<li>電子信箱：<?php echo htmlentities($dnn['email'], ENT_QUOTES, 'UTF-8'); ?></li>
			    	<li>會員電話：<?php echo htmlentities($dnn['userphone'], ENT_QUOTES, 'UTF-8'); ?></li>
			    	<li>會員系級：<?php echo htmlentities($dnn['grade'], ENT_QUOTES, 'UTF-8'); ?></li>
			    	<li>銀行代碼：<?php echo htmlentities($dnn['bank'], ENT_QUOTES, 'UTF-8'); ?></li>
			    	<li>銀行代號：<?php echo htmlentities($dnn['bankaccount'], ENT_QUOTES, 'UTF-8'); ?></li>
			<?php
			//We add a link to send a pm to the user
			?>
					<a href="new_pm.php?recip=<?php echo urlencode($dnn['username']); ?>" ><button class="btn">寄信給他</a>
			<?php
					
				}
				else
				{
					echo '此用戶不存在';
				}
			}
			else
			{
				echo '此用戶不存在';
			}
			?>
					</div>
			</div>
			<footer>
			<p>9453學生租車平台</p>
			<p>© 2017 All rights reserved.</p>
			<p>NUKIM 2017 PHP</p>
		</footer>
		</div>
	</body>
</html>