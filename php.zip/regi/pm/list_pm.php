<?php
    include('config.php');
    error_reporting(E_ALL ^ E_DEPRECATED);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/list_pm.css">
    <link rel="stylesheet" href="../CSS/all.css">
    <title>9453學生租車平台</title>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
    <script type='text/javascript'>
        $(function(){
            var $menu = $('.menu'),
                _top = $menu.offset().top;
         
            var $win = $(window).scroll(function(){
                if($win.scrollTop() >= _top){
                    if($menu.css('position')!='fixed'){
                        $menu.css({
                            position: 'fixed',
                            top: 0 
                        });
                    }
                }else{
                    $menu.css({
                        position: 'absolute',
                        top: 150
                    });
                }
            });
        });
    </script>
</head>
    <body>
        <div class="wrap">
            <div class="header">
                <a href="index.php"><h1><img src="../photo/icon.png" width="320px"></h1></a>
                <div class="user">
                    <?php 
                    if(isset($_SESSION['username'])) //2016.5.21
                    {
                    ?>
                    <p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
                    <a href="../logout.php"><button class="logout">登出</a>
                    <?php
                    }
                    else
                    {
                    ?>
                        <script>
                            alert("請先登入會員");
                            location.replace("../login.php");
                        </script>
                    <?php
                    }
                    ?>
                </div>
                <div class="clear"></div>
            </div>
            <div class="menu">
                <ul>
                    <a href="../index.php"><li>回首頁</li></a>
                    <a href="../supply_showdata.php"><li>找車子</li></a>
                    <a href="../showdata.php"><li>找委託</li></a>
                    <a href="../supply.php"><li>我要出租!</li></a>
                    <a href="../rent.php"><li>我要委託!</li></a>
                    <div class="member"><a href="../member.php"><img src="../photo/boss.png" style="width: 35px;">會員專區</a></div>
                </ul>
            </div>
            <div class="content">
                <div class="title"><h2>會員信箱/Mailbox</h2></div>
                <div class="member_bar">
                    <div class="title_2"><h3>會員功能</h3></div>
                    <a href="../orderandrent.php"><li>租借紀錄</li></a>
                    <a href="../update.php"><li>更新帳號資訊</li></a>
                   <a href="users.php"><li>會員名單</li></a>
                    <a href="../pm/index.php"><li>站內信</li></a>
                </div>
                <?php
                //We list his messages in a table
                //Two queries are executes, one for the unread messages and another for read messages
                $req1 = mysql_query('SELECT m1.id, m1.title, m1.timestamp, count(m2.id) as reps, user.id as userid, user.username from pm as m1, pm as m2,user where ((m1.user1="'.$_SESSION['username'].'" and m1.user1read="no" and user.username=m1.user2) or (m1.user2="'.$_SESSION['username'].'" and m1.user2read="no" and user.username=m1.user1)) and m1.id2="1" and m2.id=m1.id group by m1.id order by m1.id desc');
                $req2 = mysql_query('SELECT m1.id, m1.title, m1.timestamp, count(m2.id) as reps, user.id as userid, user.username from pm as m1, pm as m2,user where ((m1.user1="'.$_SESSION['username'].'" and m1.user1read="yes" and user.username=m1.user2) or (m1.user2="'.$_SESSION['username'].'" and m1.user2read="yes" and user.username=m1.user1)) and m1.id2="1" and m2.id=m1.id group by m1.id order by m1.id desc');
                ?>
                <div class="mailbox">
                    <li><a href="new_pm.php" class="link_new_pm"><button class = "mail_btn">撰寫信件</a></li>
                    <li><h4>未讀信件：<b>(<?php echo intval(mysql_num_rows($req1)); ?></b> 封)</h4></li>
                    <div class="title_cell">
                        <li><span class="subtitle">標題</span></li>
                        <li><span class="subtitle">聯絡人</span></li>
                        <li><span class="subtitle">寄出日期</span></li>
                        <div class="clear"></div>
                        <?php
                        //We display the list of unread messages
                        while($dn1 = mysql_fetch_array($req1))
                        {
                        ?>
                            <li><a href="read_pm.php?id=<?php echo $dn1['id']; ?>"><?php echo htmlentities($dn1['title'], ENT_QUOTES, 'UTF-8'); ?></a></li>
                            	<!-- <td><?php echo $dn1['reps']-1; ?></td> -->
                            <li><a href="profile.php?id=<?php echo $dn1['userid']; ?>"><?php echo htmlentities($dn1['username'], ENT_QUOTES, 'UTF-8'); ?></a></li>
                            <li><?php echo date('Y/m/d H:i:s' ,$dn1['timestamp']); ?></li>
                            <div class="clear"></div>
                        <?php
                        }
                        //If there is no unread message we notice it
                        if(intval(mysql_num_rows($req1))==0)
                        {
                        ?>
                            <li>您目前沒有未讀信件</li>
                            <div class="clear"></div>
                        <?php
                        }
                        ?>
                    </div>
                    <li><h4>已讀信件：(<b><?php echo intval(mysql_num_rows($req2)); ?></b> 封)</h4></li>
                    <div class="title_cell">
                        <li><span class="subtitle">標題</span></li>
                        <li><span class="subtitle">聯絡人</span></li>
                        <li><span class="subtitle">建立日期</span></li>
                        <div class="clear"></div>
                        <?php
                        //We display the list of read messages
                        while($dn2 = mysql_fetch_array($req2))
                        {
                        ?>
                            <li><a href="read_pm.php?id=<?php echo $dn2['id']; ?>"><?php echo htmlentities($dn2['title'], ENT_QUOTES, 'UTF-8'); ?></a></li>
                            	<!-- <td><?php echo $dn2['reps']-1; ?></td> -->
                            <li><a href="profile.php?id=<?php echo $dn2['userid']; ?>"><?php echo htmlentities($dn2['username'], ENT_QUOTES, 'UTF-8'); ?></a></li>
                            <li><?php echo date('Y/m/d H:i:s' ,$dn2['timestamp']); ?></li>
                            <div class="clear"></div>
                        <?php
                        }
                        //If there is no read message we notice it
                        if(intval(mysql_num_rows($req2))==0)
                        {
                        ?>
                            <li>您目前沒有已讀信件</li>
                            <div class="clear"></div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <footer>
                <p>9453學生租車平台</p>
                <p>© 2017 All rights reserved.</p>
                <p>NUKIM 2017 PHP</p>
            </footer>
        </div>
	</body>
</html>