﻿<?php
define("DB_TYPE","mysql");
define("DB_HOSTNAME","localhost");
define("DB_NAME","car");
define("DB_USERNAME","root");
define("DB_PASSWORD","c194xo4");
define("DB_CHARSET","utf8");
?>
