<?php
session_start();

header("Content-Type:text/html; charset=utf-8");

$link=mysqli_connect("localhost", "root", "c194xo4", "car");

$offer_ID=$_SESSION["username"];
$id=$_POST["id"];
$sql="SELECT * FROM orderr WHERE ID='$id'";
$result=mysqli_query($link, $sql);
$row=mysqli_fetch_assoc($result);
$seat=$row["seat"];
sleep(2);

//產生一個car_ID
$sql2="SELECT max(ID) FROM car WHERE ID > 0";
$result2=mysqli_query($link, $sql2);
$row2=mysqli_fetch_assoc($result2);
$car_ID=$row2["max(ID)"]+1;


if(isset($_POST["pay"]))
{
	switch ($_POST["pay"]) {
		
		case 'ATM':
			$bank_code=$_POST["bank_code"];
			$account=$_POST["account"];
			$pay=$bank_code."+".$account;
			break;
		

		case 'meeting':
			$pay="meeting";	
			break;
	}
}

$car_brand=implode(" ",$_POST["car_brand"]);
$year=$_POST["year"];


$sql4="INSERT INTO car(ID, offer_ID, brand, year, seat) VALUES ('$car_ID', '$offer_ID', '$car_brand', '$year', '$seat')";
mysqli_query($link, $sql4);
sleep(2);


$sql6="UPDATE orderr SET pay_detail='$pay',car_ID='$car_ID',offer_ID='$offer_ID' WHERE ID='$id'";
$result11=mysqli_query($link, $sql6);


if(! $result11 )
{
    echo "<script>
            alert('下單失敗，回到上一頁');
            location.replace('order.php?id='$id'');
          </script> ";   
}
echo "<script>
        alert('下單成功!跳轉至會員專區查看訂單');
        location.replace('orderandrent.php');
      </script> ";   


mysqli_close($link);

