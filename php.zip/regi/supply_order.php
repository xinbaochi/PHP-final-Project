<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="CSS/supply_order.css">
	<link rel="stylesheet" href="CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<script>
							alert("請先登入會員");
							location.replace("login.php");
					</script>	
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
		</div>
		<div class="menu">
			<ul>
				<a href="index.php"><li>回首頁</li></a>
				<a href="supply_showdata.php"><li>找車子</li></a>
				<a href="showdata.php"><li>找委託</li></a>
				<a href="supply.php"><li>我要出租!</li></a>
				<a href="rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="member.php"><img src="photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class="content">
			
			<div class="request">
				<?php

					$link=mysqli_connect('localhost', 'root', 'c194xo4', 'car'); 

					$id=$_POST["id"];

					$sql="SELECT price, pay FROM orderr WHERE ID='$id'";
					$result=mysqli_query($link, $sql);
					$row=mysqli_fetch_assoc($result);
					$pay=$row["pay"];

					$start_date=$_POST["start_date"];
					$start_time=$_POST["start_time"];
					$end_date=$_POST["end_date"];
					$end_time=$_POST["end_time"];

					//計算租車的天數
					$start=strtotime($start_date);
					$end=strtotime($end_date);
					$days=round(($end-$start)/3600/24+1);

					//存入出遊月份(以起始日所在月份判斷)
					if(isset($start_date))
					{
						$month=split('[/.-]',$start_date);
						$month_number=$month[1];
					}
			
			
					//回傳資料
					$sql2="UPDATE orderr SET start_date = '$start_date', start_time = '$start_time', end_date = '$end_date', end_time = '$end_time', days = '$days', month = '$month_number' WHERE ID ='$id'";

					mysqli_query($link, $sql2);


				?>
				<form action="supply_saveorder.php" method="post">
					<h2>我要租車車</h2>

					<?php
						echo "<input type='hidden' name='id' value='".$id."'>";//用hidden的input來傳到save_order 
						echo "<li>租車時間：".$start_date."  ".$start_time." ~ ".$end_date."  ".$end_time."</li>";
						echo "<li>價格：".$row["price"]."元 / 天<br>";
						echo "<li>總金額：".$days."天 X".$row["price"]."元 =".$days*$row["price"]."元</li>";
						echo "<li>付款方式：</li>";
						switch($pay)
						{
				          		case "ATM";
				         	 	echo "<li><input type='radio' name='pay' value='ATM'>實體ATM</li>";
					  		break;

				         	 	case "meeting";
				          		echo "<li><input type='radio' name='pay' value='meeting'>面交</li>";
				          		break;
				 
				          		case "ATM meeting";
				          		echo "<input type='radio' name='pay' value='ATM'>實體ATM";
							echo "<input type='radio' name='pay' value='meeting'>面交";
						}
						echo "</li>";
						mysqli_close($link);
					?>

					<input type="submit" name="submit" value="確認" class="btn">
				</form> 

				</div>
			</div>
			<footer>
				<p>9453學生租車平台</p>
				<p>© 2017 All rights reserved.</p>
				<p>NUKIM 2017 PHP</p>
			</footer>
		</div>
	</body>
</html>
