<?php
session_start();
$link=mysqli_connect("localhost", "root", "c194xo4", "car");

$rent_id=$_SESSION['username'];
$seat=implode(",",$_POST["seat"]);
$rent_date=$_POST["rent_date"];
$rent_time=$_POST["rent_time"];
$back_date=$_POST["back_date"];
$back_time=$_POST["back_time"];
$rent_price=$_POST["rent_price"];
$rent_pay=implode(",",$_POST["rent_pay"]);
$rent_remark=$_POST["rent_remark"];


//計算租車的天數
$start=strtotime($rent_date);
$end=strtotime($back_date);
$days=round(($end-$start)/3600/24+1);

//存入出遊月份(以起始日所在月份判斷)
if(isset($rent_date))
{
	$month=split('[/.-]',$rent_date);
	$month_number=$month[1];
}


$result=mysqli_query($link,"INSERT INTO orderr (rent_ID, seat, start_date, start_time, end_date, end_time, price, pay, days, remark, month) VALUES('".$_SESSION['username']."', '$seat', '$rent_date', '$rent_time', '$back_date', '$back_time', '$rent_price', '$rent_pay', '$days', '$rent_remark', '$month_number')");

header("Location:showdata.php");

mysqli_close($link);

?>
