﻿<?php
	session_start();
	require_once("config.inc.php"); 
	$username = $_SESSION['username'];
	$row = $member->getUserinfoBn($username);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="CSS/update.css">
	<link rel="stylesheet" href="CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});
	</script>
	<script>
		$(document).ready(function(){
			$('.login_btn').hover(function(){$('b1').text("按此登入")},function(){$('b1').text("您尚未登入!")});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<script>
							alert("請先登入會員");
							location.replace("login.php");
					</script>	
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
		</div>
		<div class="menu">
			<ul>
				<a href="index.php"><li>回首頁</li></a>
				<a href="supply_showdata.php"><li>找車子</li></a>
				<a href="showdata.php"><li>找委託</li></a>
				<a href="supply.php"><li>我要出租!</li></a>
				<a href="rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="member.php"><img src="photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class="content">
			<div class="title"><h2>會員專區/Member</h2></div>
				<div class="member_bar">
					<div class="title_2"><h3>會員功能</h3></div>
					<a href="orderandrent.php"><li>租借紀錄</li></a>
					<a href="update.php"><li>更新帳號資訊</li></a>
					<a href="pm/users.php"><li>會員名單</li></a>
					<a href="pm/index.php"><li>站內信</li></a>
				</div>
				<div class="update">
					<?php if(isset($_SESSION['level'])):?>
						<h4>更改會員資料</h4>
						<form method="post" action="updatec.php" name="reg">
							<li>使用者：<input name="username" type="text" readonly="readonly" value="<?php echo $row['username'];?>"></li>
							<li>email：<input name="email" type="text" value="<?php echo $row['email'];?>"></li>
							<li>密碼：<input name="password" type="password"></li>
							<li>確認密碼：<input name="password1" type="password"></li>
							<li>手機號碼：<input name="userphone" type="text" value="<?php echo $row['userphone'];?>"></li>
							<li>匯款銀行代碼：<input name="bank" type="text" value="<?php echo $row['bank'];?>"></li>
							<li><a href="http://web.thu.edu.tw/s932954/www/ruten/banklist.htm" target="_blank" title="銀行代碼一覽表">銀行代碼一覽表</a></li>
							<li>匯款銀行帳號：<input name="bankaccount" type="text" value="<?php echo $row['bankaccount'];?>"></li>
							<li><input name="level" type="hidden" value="<?php echo $row['level'];?>"></li>
							<li><input name="reg" value="確認更改" type="submit" class="btn"></li>
						</form>
					<?php endif;?>
				</div>
		</div>
		<footer>
			<p>9453學生租車平台</p>
			<p>© 2017 All rights reserved.</p>
			<p>NUKIM 2017 PHP</p>
		</footer>
	</div>
</body>
</html>