<?php
	session_start();	
	header("Content-Type:text/html; charset=utf-8");
	$link=mysqli_connect("localhost", "root", "c194xo4", "car");
	$id=$_GET["id"];

	$sql="SELECT * from orderr WHERE ID='$id'";
	$result=mysqli_query($link, $sql);
	$row=mysqli_fetch_assoc($result);
	$car_ID=$row["car_ID"];


	$sql2="SELECT * from car WHERE ID='$car_ID'";
	$result2=mysqli_query($link, $sql2);
	$row2=mysqli_fetch_assoc($result2);


	$rent_ID=$row["rent_ID"];
	$sql3="SELECT * FROM user,orderr WHERE username='$rent_ID'";
	$result3=mysqli_query($link, $sql3);
	$row3=mysqli_fetch_assoc($result3);


	$offer_ID=$row["offer_ID"];
	$sql4="SELECT email,userphone,bank,bankaccount FROM user,orderr WHERE username='$offer_ID'";
	$result4=mysqli_query($link, $sql4);
	$row4=mysqli_fetch_assoc($result4);


	echo "<h1># ".$row["ID"]." 訂單詳細資訊</h1>";
	
	echo "<h2>委託者資訊</h2>";
	echo "<li>ID：".$row["rent_ID"]."</li>";
	echo "<li>E-mail：".$row3["email"]."</li>";
	echo "<li>聯絡電話：".$row3["userphone"]."</li>";


	echo "<h2>車主資訊</h2>";
	echo "<li>ID：".$row["offer_ID"]."</li>";
	echo "<li>E-mail：".$row4["email"]."</li>";
	echo "<li>聯絡電話：".$row4["userphone"]."</li>";

	echo "<h2>訂單資訊</h2>";
	echo "<li>租車時間：".$row["start_date"]."  ".$row["start_time"]."</li>";
	echo "<li>還車時間：".$row["end_date"]."  ".$row["end_time"]."</li>";
	echo "<li>車子品牌：".$row2["brand"]."</li>";
	echo "<li>車齡：".$row2["year"]."</li>";
	echo "<li>車型等級：".$row2["seat"]."</li>";
	echo "<h2>付款資訊</h2>";
	echo "<li>總金額：".$row["price"]*$row["days"]."元</li>";
	echo "<li>繳費方式：";

	switch($row["pay"]){
		case 'ATM' :
			$ATM_account=$row["pay_detail"];
			$ATM_account=split ('[+.-]',$ATM_account);
			echo "實體ATM轉帳</li>";
			echo "<li>銀行代碼：".$ATM_account[0]."</li>";
			echo "<li>銀行帳號：".$ATM_account[1]."</li>";
			break;
		
		case 'meeting':
			echo "面交</li>";
			break; 

}

?>
