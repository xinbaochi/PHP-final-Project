<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="CSS/orderandrent.css">
	<link rel="stylesheet" href="CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<script>
						alert("請先登入會員");
						location.replace("login.php");
					</script>	
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
		</div>
		<div class="menu">
			<ul>
				<a href="index.php"><li>回首頁</li></a>
				<a href="supply_showdata.php"><li>找車子</li></a>
				<a href="showdata.php"><li>找委託</li></a>
				<a href="supply.php"><li>我要出租!</li></a>
				<a href="rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="member.php"><img src="photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class = "content">
			<div class="title"><h2>出租紀錄/Rent Log</h2></div>
			<div class="member_bar">
				<div class="title_2"><h3>會員功能</h3></div>
				<a href="orderandrent.php"><li>租借紀錄</li></a>
				<a href="update.php"><li>更新帳號資訊</li></a>
				<a href="pm/users.php"><li>會員名單</li></a>
				<a href="pm/index.php"><li>站內信</li></a>
			</div>
			<div class="order">
				<div class="title_3"><h4>出租車子</h4></div>
				<li class="subtitle">編號</li>
				<li class="subtitle">車主ID</li>
				<li class="subtitle">車子品牌</li>
				<li class="subtitle">車型等級</li>
				<li class="subtitle">車齡</li>
				<li class="subtitle">備註</li>
				<div class="clear"></div>
			<?php 
				if($_SESSION['level']=="admin"){
				$link=mysqli_connect("localhost", "root", "c194xo4", "car");
				$sql="SELECT * FROM car,orderr where car.ID = orderr.car_ID and orderr.rent_ID is null ";
				}else{
				$link=mysqli_connect("localhost", "root", "c194xo4", "car");
				$sql="SELECT * FROM car,orderr where car.ID = orderr.car_ID and orderr.rent_ID is null and offer_ID = '".$_SESSION['username']."'";
				}
				$result=mysqli_query($link, $sql);
				$row=mysqli_fetch_assoc($result);
				while($row=mysqli_fetch_assoc($result)){
					$id=$row["ID"];
					$sql1="SELECT orderr.`ID` FROM orderr where '$id'=car_ID ";
					$result1=mysqli_query($link, $sql1);
					$row1=mysqli_fetch_assoc($result1);
					$ID=$row1["ID"];
					?>
					<li><?php echo $row["ID"] ?></li>
					<li><?php echo $row["offer_ID"] ?></li>
					<li><?php echo $row["brand"] ?></li>
					<li><?php echo $row["seat"] ?></li>
					<li><?php echo $row["year"] ?></li>
					<li><?php echo $row["remark"] ?></li>
					<li><?php echo "<a href='supply_detail.php?id=".$id."'>"; ?><button class="view_btn">查看</a></li>
					<li><?php echo "<a href='supplydelete.php?id=".$id."'>"; ?><button class="delete_btn">刪除</a></li>
					<div class="clear"></div>
			<?php
				}
			?>
			</div>	
			
			<div class="order">
				<div class="title_3"><h4>委託案子</h4></div>
				<li class="subtitle">編號</li>
				<li class="subtitle">委託ID</li>
				<li class="subtitle">開始日期</li>
				<li class="subtitle">結束日期</li>
				<li class="subtitle">價格</li>
				<li class="subtitle">租借天數</li>
				<div class="clear"></div>
			<?php 
				if($_SESSION['level']=="admin"){
				$link=mysqli_connect("localhost", "root", "c194xo4", "car");
				$sql="SELECT * FROM orderr where offer_ID is null ";
				}else{
				$link=mysqli_connect("localhost", "root", "c194xo4", "car");
				$sql="SELECT * FROM orderr where offer_ID is null and rent_ID ='".$_SESSION['username']."' ";
				}
				$result=mysqli_query($link, $sql);
				$row=mysqli_fetch_assoc($result);
				while($row=mysqli_fetch_assoc($result)){
					$ID=$row["ID"]
					?>
					<li><?php echo $row["ID"] ?></li>
					<li><?php echo $row["rent_ID"] ?></li>
					<li><?php echo $row["start_date"] ?></li>
					<li><?php echo $row["end_date"] ?></li>
					<li><?php echo $row["price"] ?></li>
					<li><?php echo $row["days"] ?></li>
					<li><?php echo "<a href='detail.php?id=".$ID."'>"; ?><button class="view_btn">查看</a></li>
					<li><?php echo "<a href='detaildelete.php?id=".$ID."'>"; ?><button class="delete_btn">刪除</a></li>
					<div class="clear"></div>
			<?php
				}
			?>
			</div>
			
			<div class="order">
				<div class="title_3"><h4>已完成的案子</h4></div>
				<li class="subtitle">編號</li>
				<li class="subtitle">車子編號</li>
				<li class="subtitle">委託ID</li>
				<li class="subtitle">車主ID</li>
				<div class="clear"></div>
			<?php
			if($_SESSION['level']=="admin"){
				$link=mysqli_connect("localhost", "root", "c194xo4", "car");
				$sql="SELECT * FROM orderr where rent_ID is not null and offer_ID is not null ";
				}else{
				$link=mysqli_connect("localhost", "root", "c194xo4", "car");
				$sql="SELECT * FROM orderr where offer_ID is not null and rent_ID ='".$_SESSION['username']."' ";
				} 
				$result=mysqli_query($link, $sql);
				$row=mysqli_fetch_assoc($result);
				while($row=mysqli_fetch_assoc($result)){
					$ID=$row["ID"]
					?>
					<li><?php echo $row["ID"] ?></li>
					<li><?php echo $row["car_ID"] ?></li>
					<li><?php echo $row["rent_ID"] ?></li>
					<li><?php echo $row["offer_ID"]?></li>
					<li><?php echo "<a href='check_detail.php?id=".$ID."'>"; ?><button class="view_btn">查看</a></li>
					<div class="clear"></div>	
			<?php
				}
			?>
			</div>																
		</div>
		<footer>
			<p>9453學生租車平台</p>
			<p>© 2017 All rights reserved.</p>
			<p>NUKIM 2017 PHP</p>
		</footer>
	</div>
</body>
</html>
