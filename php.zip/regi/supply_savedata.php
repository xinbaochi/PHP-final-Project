<?php
session_start();

$link=mysqli_connect("localhost", "root", "c194xo4", "car");
//mysqli_query("SET NAMES'utf8'");

$offer_ID=$_SESSION["username"];

//產生一個car_ID
$sql3="SELECT max(ID) FROM car WHERE ID > 0";
$result3=mysqli_query($link, $sql3);
$row3=mysqli_fetch_assoc($result3);
$car_ID=$row3["max(ID)"]+1;

$car_brand=implode(" ",$_POST["car_brand"]);
$year=$_POST["year"];
$seat=implode(" ",$_POST["seat"]);
$car_price=$_POST["car_price"];
$car_pay=implode(" ",$_POST["car_pay"]);
$supply_date=$_POST["supply_date"];
$back_date=$_POST["back_date"];
$remark=$_POST["remark"];


//判斷付費方式
if(isset($car_pay))
{
	switch ($car_pay) {
		
		case 'ATM':
			$bank_code=$_POST["bank_code"];
			$account=$_POST["account"];
			$pay_detail=$bank_code."+".$account;
			break;
		
		case 'meeting':
			$pay_detail="meeting";	
			break;

		case 'ATM meeting':
			$bank_code=$_POST["bank_code"];
                        $account=$_POST["account"];
                        $pay_detail=$bank_code."+".$account;
	}
}

//將car資訊寫進資料庫
$sql="INSERT INTO car(ID, brand, seat, year, remark, offer_ID) VALUE ('$car_ID', '$car_brand', '$seat', '$year', '$remark', '$offer_ID')";
mysqli_query($link, $sql);
sleep(3);

//計算天數
$start=strtotime($supply_date);
$end=strtotime($back_date);
$days=round(($end-$start)/3600/24+1);

//將orderr資訊寫進資料庫
$sql2="INSERT INTO orderr(car_ID, seat, price, pay, start_date, end_date, pay_detail, days, remark, offer_ID) VALUE ('$car_ID', '$seat', '$car_price', '$car_pay', '$supply_date', '$back_date', '$pay_detail', '$days', '$remark', '$offer_ID')";
mysqli_query($link, $sql2);
sleep(3);

header("Location: supply_showdata.php");


