<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="CSS/supply_detail.css">
	<link rel="stylesheet" href="CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});

		$(function(){
			var $book = $('.book'),
				_top = $book.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($book.css('position')!='fixed'){
						$book.css({
							position: 'fixed',
							top: 55 
						});
					}
				}else{
					$book.css({
						position: 'absolute',
						top: 290
					});
				}
			});
		});
	</script>
	<script>
		$(document).ready(function(){
			$('.login_btn').hover(function(){$('b1').text("按此登入")},function(){$('b1').text("您尚未登入!")});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="../logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<div class="login_btn"><a href="login.php"><b1>您尚未登入！</b1></a></div>
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
			<?php

				header("Content-Type:text/html; charset=utf-8");

				$link=mysqli_connect("localhost", "root", "c194xo4", "car");

				$id=$_GET["id"];
				$sql="DELETE FROM `car`.`orderr` WHERE `orderr`.`ID` = '$id'";

			?>
		</div>
		<div class="menu">
			<ul>
				<a href="index.php"><li>回首頁</li></a>
				<a href="supply_showdata.php"><li>找車子</li></a>
				<a href="showdata.php"><li>找委託</li></a>
				<a href="supply.php"><li>我要出租!</li></a>
				<a href="rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="member.php"><img src="photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class="delete">
				<?php if($_SESSION['level']=="admin"):
					mysqli_query($link,$sql)or die ("無法刪除".mysql_error());
					echo "刪除成功!";
					echo '<meta http-equiv="refresh" content="1; url=orderandrent.php">';
				?>
				<?php elseif($_SESSION['level']=="user"):?>
					<li style="color:red;">帳號權限不足！</span></li>
					<li style="color:red;">目前您的帳號權限為一般會員</li>
				<?php else:?>
					<li style="color:red;">您尚未登入！</li>
				<?php endif;?>
			</div>
		<footer>
			<p>9453學生租車平台</p>
			<p>© 2017 All rights reserved.</p>
			<p>NUKIM 2017 PHP</p>
		</footer>
	</div>
</body>
</html>
