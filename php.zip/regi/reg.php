<!DOCTYPE html>
<html lang="zh-TW">

	<head>
		<meta charset="UTF8">
		<title>註冊</title>
		<link rel="stylesheet" href="CSS/reg.css">
		<link rel="stylesheet" href="CSS/all.css">
	</head>

	<body>
		<div class="wrap" style="text-align: center;">
			<img src="photo/LoginIcon.png" width="400px">
			<div class="register">
				<h1>註冊/Register</h1>
				<form method="post" action="regc.php" name="reg">
					<li><font color="#FF0000">*者為必填項目</font></li>
					<li><font color=red>*</font>使用者帳號：<input name="username" type="text" maxlength="20"></li>
					<li>(英文數字皆可，4~20字以內)</li>
					<li><font color=red>*</font>email：<input name="email" type="text"></li>
					<li><font color=red>*</font>密碼：<input name="password" type="password" maxlength="20"></li>
					<li>(英文數字皆可，不得超過20字)</li>
					<li><font color=red>*</font>請再輸入一次密碼：<input name="password2" type="password" maxlength="20"></li>
					<li><font color=red>*</font>手機號碼：<input name="userphone" type="text" maxlength="10"></li>
					<li><font color=red>*</font>系級：<input name="grade" type="text" maxlength="3" value="1XX"></li>
					<li>匯款銀行代碼：<input name="bank" type="text"></li>
					<li><a href="http://web.thu.edu.tw/s932954/www/ruten/banklist.htm" target="_blank" title="銀行代碼一覽表">銀行代碼一覽表</a></li>
					<li>匯款銀行帳號：<input name="bankaccount" type="text"></li>
					<li><input name="reg" value="註冊" type="submit" class="btn"></li>
					<div id="msg"></div>
					<li>已有帳號？<a href="login.php">登入</a></li>
				</form>
				
			</div>			
		</div>
	</body>

</html>