<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="CSS/index.css">
	<link rel="stylesheet" href="CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});
	</script>
	<script>
		$(document).ready(function(){
			$('.login_btn').hover(function(){$('b1').text("按此登入")},function(){$('b1').text("您尚未登入!")});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<div class="login_btn"><a href="login.php"><b1>您尚未登入！</b1></a></div>
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
		</div>
		<div class="menu">
			<ul>
				<a href="supply_showdata.php"><li>找車子</li></a>
				<a href="showdata.php"><li>找委託</li></a>
				<a href="supply.php"><li>我要出租!</li></a>
				<a href="rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="member.php"><img src="photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class="content">
			<div class="search">
				<h2>搜尋車子 &nbsp </h2><img src="photo/car.png" style="width: 40px;">
				<form method="post" action="searchcar.php" enctype="multipart/form-data">
					<input type="hidden" name="search" value="1">
					<li>車型等級 ： <select name="seat">
	    						 <option value="5">五人座</option>
	    						 <option value="7">七人座</option>
							</select></li>
					<li>租用起始日 : <input type="date" id="bookdate" name="start_date"></li>
					<li>可租用天數 : <input type="text" style="width:60px;" name="days"> 天</li>
					<li>價格 : <input type="text" style="width:60px;" name="price_1"> ~ <input type="text" style="width:60px;" name="price_2"></li>
					<input type="submit" id="btn" value="搜尋">
				</form>
			</div>
			<div class="search">
				<h2>搜尋委託 &nbsp </h2><img src="photo/order.png" style="width: 30px;">
				<form method="post" action="searchrent.php" enctype="multipart/form-data">
					<input type="hidden" name="search" value="2">
					<li>車型等級 ： <select name="seat">
	    						<option value="5">五人座</option>
	    						<option value="7">七人座</option>
							</select></li>
					<li>租用起始日 : <input type="date" id="bookdate_2" name="start_date"></li>
					<li>租用天數 : <input type="text" style="width:60px;" name="days"> 天</li>
					<li>價格 : <input type="text" style="width:60px;" name="price_1"> ~ <input type="text" style="width:60px;" name="price_2"></li>
					<input type="submit" id="btn" value="搜尋">
				</form>
			</div>

			<script>
				function convertToISO(timebit) {
				  // remove GMT offset
				  timebit.setHours(0, -timebit.getTimezoneOffset(), 0, 0);
				  // format convert and take first 10 characters of result
				  var isodate = timebit.toISOString().slice(0,10);
				  return isodate;
				}

				var bookdate = document.getElementById('bookdate');
				var currentdate = new Date();
				bookdate.min = convertToISO(currentdate);
				bookdate.placeholder = bookdate.min;
				var futuredate = new Date();
				futuredate.setDate(futuredate.getDate() + 30);
				bookdate.max = convertToISO(futuredate);

				function convertToISO(timebit) {
				  // remove GMT offset
				  timebit.setHours(0, -timebit.getTimezoneOffset(), 0, 0);
				  // format convert and take first 10 characters of result
				  var isodate = timebit.toISOString().slice(0,10);
				  return isodate;
				}

				var bookdate = document.getElementById('bookdate_2');
				var currentdate = new Date();
				bookdate.min = convertToISO(currentdate);
				bookdate.placeholder = bookdate.min;
				var futuredate = new Date();
				futuredate.setDate(futuredate.getDate() + 30);
				bookdate.max = convertToISO(futuredate);
			</script>

			<div class="clear"></div>
			<div class="news">
				<h3>最新租車資訊</h3>
				<?php
					$link=mysqli_connect("localhost", "root", "c194xo4", "car");
					$sql2="SELECT orderr.ID, orderr.seat, orderr.start_date, orderr.days, orderr.price FROM orderr, car WHERE orderr.rent_ID is null and orderr.car_ID = car.ID ORDER BY  `orderr`.`ID` DESC Limit 1";     //選擇所有rent欄位
					$result=mysqli_query($link, $sql2);      //執行SQL查詢
					while($row2=mysqli_fetch_assoc($result)){
						?>
						
						<div class="new_title">
							<li>租車編號</li>
							<li>車廠品牌</li>
							<li>租用起始日</li>
							<li>可租用天數</li>
							<li>價格</li>
						</div>
						<div class="new_content">
							<li># <?php echo $row2["ID"]; $id2=$row2["ID"]; ?></li>
							<li><?php echo $row2["seat"]; ?> 人座</li>
							<li><?php echo $row2["start_date"]; ?></li>
							<li><?php echo $row2["days"]; ?> 天</li>
							<li><?php echo $row2["price"]; ?> 元</li>
						</div>
					<?php
					}
				?>
				<a href="supply_detail.php?id=<?php echo $id2; ?>"><button class="new_btn">點此詳情</a>
			</div>
			<div class="news">
				<h3>最新委託資訊</h3>
				<?php
					$sql="SELECT * FROM orderr WHERE offer_ID is null ORDER BY  `orderr`.`ID` DESC Limit 1";     //選擇所有rent欄位
					$result=mysqli_query($link, $sql);      //執行SQL查詢
					while($row=mysqli_fetch_assoc($result)){
						?>
						
						<div class="new_title_2">
							<li>委託編號</li>
							<li>車型等級需求</li>
							<li>租用起始日</li>
							<li>可租用天數</li>
							<li>價格</li>
						</div>
						<div class="new_content">
							<li># <?php echo $row["ID"]; $id=$row["ID"]; ?></li>
							<li><?php echo $row["seat"]; ?> 人座</li>
							<li><?php echo $row["start_date"]; ?></li>
							<li><?php echo $row["days"]; ?> 天</li>
							<li><?php echo $row["price"]; ?> 元</li>
						</div>
					<?php
					}
				?>
				<a href="detail.php?id=<?php echo $id; ?>"><button class="new_btn">點此詳情</a>
			</div>
		</div>
		<div class="clear"></div>
			<footer>
				<p>9453學生租車平台</p>
				<p>© 2017 All rights reserved.</p>
				<p>NUKIM 2017 PHP</p>
			</footer>
	</div>
</body>
</html>
