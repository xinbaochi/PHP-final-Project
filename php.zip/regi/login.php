<?php
session_start();   //開啟session
if(isset($_SESSION['username'])){
 header("refresh:0;url=member.php");  //轉址
 exit(); //不執行之後的程式碼
}
?>
<!DOCTYPE html>
<html lang="zh-TW">

	<head>
		<meta charset="UTF8">
		<title>登入</title>
		<link rel="stylesheet" href="CSS/login.css">
		<link rel="stylesheet" href="CSS/all.css">
	</head>

	<body>
		<div class="wrap" style="text-align: center;">
			<img src="photo/LoginIcon.png" width="400px">
			<div class="login">
				<h1>登入/Login</h1>
				<form method="post" action="loginc.php" name="login">
					<li>使用者帳號：<input name="username" type="text"></li>
					<li>密碼：<input name="password" type="password"></li>
					<li><input name="login" value="登入" type="submit" class="btn"></li>
					<li>沒有帳號？<a href="reg.php">註冊</a></li>
				</form>
			</div>			
		</div>
	</body>

</html>