
<?php
session_start();

header("Content-Type:text/html; charset=utf-8");

$link=mysqli_connect("localhost", "root", "c194xo4", "car");

$offer_ID = $_SESSION["username"];
$id=$_POST["id"];
$sql="SELECT * FROM orderr WHERE ID='$id'";
$result=mysqli_query($link, $sql);
$row=mysqli_fetch_assoc($result);
$seat=$row["seat"];


//產生一個car_ID
$sql2="SELECT max(ID) FROM car WHERE ID > 0";
$result2=mysqli_query($link, $sql2);
$row2=mysqli_fetch_assoc($result2);
$car_ID=$row2["max(ID)"]+1;

if(isset($_POST["pay"]))
{
	switch ($_POST["pay"]) {
		
		case 'ATM':
			$bank_code=$_POST["bank_code"];
			$account=$_POST["account"];
			$pay_detail=$bank_code."+".$account;
			break;
		

		case 'meeting':
			$pay_detail="meeting";	
			break;
	}
}

$car_brand=implode(" ",$_POST["car_brand"]);
$year=$_POST["year"];


$sql3="UPDATE orderr SET pay_detail = '$pay_detail' ,car_ID = '$car_ID' ,offer_ID = '$offer_ID' WHERE ID = '$id'";
$result=mysqli_query($link, $sql3);
sleep(2);


$sql4="INSERT INTO car(ID, offer_ID, brand, year, seat) VALUES ('$car_ID', '$offer_ID', '$car_brand', '$year', '$seat')";
$result=mysqli_query($link, $sql4);
sleep(2);

echo "<script>
		alert('訂單成立!');
		location.replace('index.php');
	</script>";

mysqli_close($link);
