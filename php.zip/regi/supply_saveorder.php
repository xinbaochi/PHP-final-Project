<?php
session_start();
header("Content-Type:text/html; charset=utf-8");
$link=mysqli_connect("localhost", "root", "c194xo4", "car");

$id=$_POST["id"];
$pay=$_POST["pay"];

$rent_ID = $_SESSION["username"];
$sql="SELECT * FROM orderr WHERE ID='$id'";
$result=mysqli_query($link, $sql);
$row=mysqli_fetch_assoc($result);

//印出繳費資訊與訂單成功
switch($pay)
{
	case "ATM":
	$sql3="UPDATE orderr SET rent_ID = '$rent_ID' WHERE ID='$id'";
	mysqli_query($link, $sql3);
	$ATM_account=$row["pay_detail"];
	$ATM_account=split ('[+.-]',$ATM_account);
	echo "繳費資訊：<br>";
	echo "總金額：".$row["price"]*$row["days"]."元<br>";
	echo "銀行代碼：".$ATM_account[0]."<br>";
	echo "銀行帳號：".$ATM_account[1]."<br>";
	echo "<br>下單成功!<br>";
	break;

	case "meeting":
	$sql3="UPDATE orderr SET rent_ID = '$rent_ID' ,pay_detail = '$pay' WHERE ID='$id'";
	mysqli_query($link, $sql3);
	echo "繳費資訊：<br>";
	echo "總金額：".$row["price"]*$row["days"]."元<br>";
	echo "<br>下單成功!<br>";
	break;
}

mysqli_close($link);
