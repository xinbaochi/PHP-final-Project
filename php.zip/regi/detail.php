<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="CSS/supply_detail.css">
	<link rel="stylesheet" href="CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});

		$(function(){
			var $book = $('.book'),
				_top = $book.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($book.css('position')!='fixed'){
						$book.css({
							position: 'fixed',
							top: 55 
						});
					}
				}else{
					$book.css({
						position: 'absolute',
						top: 290
					});
				}
			});
		});
	</script>
	<script>
		$(document).ready(function(){
			$('.login_btn').hover(function(){$('b1').text("按此登入")},function(){$('b1').text("您尚未登入!")});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="../logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<div class="login_btn"><a href="login.php"><b1>您尚未登入！</b1></a></div>
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
			<?php
				header("Content-Type:text/html; charset=utf-8");

				$link=mysqli_connect("localhost", "root", "c194xo4", "car");

				$id=$_GET["id"];

				$sql="SELECT * FROM orderr WHERE ID='".$id."'";

				$result=mysqli_query($link, $sql);

				$row=mysqli_fetch_assoc($result);

				$sql3="SELECT * FROM user,orderr WHERE username= orderr.rent_ID";
				$result3=mysqli_query($link, $sql3);
				$row3=mysqli_fetch_assoc($result3);
			?>
		</div>
		<div class="menu">
			<ul>
				<a href="index.php"><li>回首頁</li></a>
				<a href="supply_showdata.php"><li>找車子</li></a>
				<a href="showdata.php"><li>找委託</li></a>
				<a href="supply.php"><li>我要出租!</li></a>
				<a href="rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="member.php"><img src="photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class="content">
			<div class="title"><h2># <?php echo $row["ID"] ?></h2></div>
				<div class="car_profile">
					<div class="title"><h3>委託需求</h3></div>
					<li>車型等級需求：<?php echo $row["seat"]; ?> 人座</li>
					<li>可付款方式：
						<?php switch($row["pay"])
							{
								case "ATM";
								echo "實體ATM轉帳";
								break;

								case "meeting";
								echo "面交";
								break;
								
								case "ATM meeting";
								echo "實體ATM轉帳 & 面交";
								break;
							} ?>
						</li>
					<div class="title"><h3>委託者資訊</h3></div>
					<li>ID：<a href="pm/new_pm.php?recip=<?php echo urlencode($row['rent_ID']); ?> "><?php echo $row["rent_ID"]; ?></a></li>
					<li>E-mail：<?php echo $row3["email"]; ?></li>
					<li>聯絡電話：<?php echo $row3["userphone"]; ?></li>
					<li>銀行代碼：<?php echo $row3["bank"]; ?></li>
					<li>銀行代號：<?php echo $row3["bankaccount"]; ?></li>
				</div>
			</div>

			<div class="book">
				<div class="book_price">
					<p>$<?php echo $row["price"] ?>元</p>
					<b>每天</b>
				</div>
				<div class="book_info">
					<form method="POST" action="order.php">
						<?php echo "<input type='hidden' name='id' value='$id'>"; ?>
						<p>租借日期</p>
						<p>租借時間</p>
						<b><?php echo $row["start_date"] ?></b><b><?php echo $row["start_time"] ?></b>
						<div class="clear"></div>
						<p>歸還日期</p>
						<p>歸還時間</p>
						<b><?php echo $row["end_date"] ?></b><b><?php echo $row["end_time"] ?></b>
						<div class="clear"></div>
						<a href='order.php?id="<?php $id ?>"'><button type="submit">我要出租!</button></a>
					</form>
				</div>
			</div>
		</div>
		<footer>
			<p>9453學生租車平台</p>
			<p>© 2017 All rights reserved.</p>
			<p>NUKIM 2017 PHP</p>
		</footer>
	</div>
</body>
</html>
