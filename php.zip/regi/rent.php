<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="CSS/rent.css">
	<link rel="stylesheet" href="CSS/all.css">
	<title>9453學生租車平台</title>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script type='text/javascript'>
		$(function(){
			var $menu = $('.menu'),
				_top = $menu.offset().top;
		 
			var $win = $(window).scroll(function(){
				if($win.scrollTop() >= _top){
					if($menu.css('position')!='fixed'){
						$menu.css({
							position: 'fixed',
							top: 0 
						});
					}
				}else{
					$menu.css({
						position: 'absolute',
						top: 150
					});
				}
			});
		});
	</script>
</head>

<body>
	<div class="wrap">
		<div class="header">
			<a href="index.php"><h1><img src="photo/icon.png" width="320px"></h1></a>
			<div class="user">
				<?php 
				if(isset($_SESSION['username'])) //2016.5.21
				{
				?>
				<p><?php echo $_SESSION['username'];?>,歡迎回來!</p>
				<a href="logout.php"><button class="logout">登出</a>
				<?php
				}
				else
				{
				?>
					<script>
							alert("請先登入會員");
							location.replace("login.php");
					</script>	
				<?php
				}
				?>
			</div>
			<div class="clear"></div>
		</div>
		<div class="menu">
			<ul>
				<a href="index.php"><li>回首頁</li></a>
				<a href="supply_showdata.php"><li>找車子</li></a>
				<a href="showdata.php"><li>找委託</li></a>
				<a href="supply.php"><li>我要出租!</li></a>
				<a href="rent.php"><li>我要委託!</li></a>
				<div class="member"><a href="member.php"><img src="photo/boss.png" style="width: 35px;">會員專區</a></div>
			</ul>
		</div>
		<div class="content">
			
			<div class="request">
				<h2>我要PO委託</h2>
				<form action="savedata.php" method="post">
					<li>車型等級：<select name="seat[]">
				    		<option value="5">五人座</option>
				    		<option value="7">七人座</option>
						</select></li>

					<li>租車日期：<input name="rent_date" type="date" id="bookdate"></li>
					<li>租車時間：<input name="rent_time" type="time"></li>
			        <li>還車日期：<input name="back_date" type="date" id="bookdate_2"></li>
			        <li>還車時間：<input name="back_time" type="time"></li>

					<li>價格：<input name="rent_price" type="text"> / 天</li>

					<li>可付款的方式：
					<input type="checkbox" name="rent_pay[]" value="ATM">實體ATM轉帳
					<input type="checkbox" name="rent_pay[]" value="meeting">面交</li>
					
					<li>附註：<br><br>
					<textarea name="rent_remark" cols="45" rows="5" placeholder="若有特殊要求請在此填寫"></textarea></li>
					<li><input type="submit" name="send" class="btn"></li>
				</form>
				<script>
				function convertToISO(timebit) {
				  // remove GMT offset
				  timebit.setHours(0, -timebit.getTimezoneOffset(), 0, 0);
				  // format convert and take first 10 characters of result
				  var isodate = timebit.toISOString().slice(0,10);
				  return isodate;
				}

				var bookdate = document.getElementById('bookdate');
				var currentdate = new Date();
				bookdate.min = convertToISO(currentdate);
				bookdate.placeholder = bookdate.min;
				var futuredate = new Date();
				futuredate.setDate(futuredate.getDate() + 30);
				bookdate.max = convertToISO(futuredate);

				function convertToISO(timebit) {
				  // remove GMT offset
				  timebit.setHours(0, -timebit.getTimezoneOffset(), 0, 0);
				  // format convert and take first 10 characters of result
				  var isodate = timebit.toISOString().slice(0,10);
				  return isodate;
				}

				var bookdate = document.getElementById('bookdate_2');
				var currentdate = new Date();
				bookdate.min = convertToISO(currentdate);
				bookdate.placeholder = bookdate.min;
				var futuredate = new Date();
				futuredate.setDate(futuredate.getDate() + 30);
				bookdate.max = convertToISO(futuredate);
			</script>
			</div>
		</div>
			<footer>
				<p>9453學生租車平台</p>
				<p>© 2017 All rights reserved.</p>
				<p>NUKIM 2017 PHP</p>
			</footer>
	</body>
</html>
