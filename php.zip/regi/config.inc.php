﻿<?php
require_once("config.php");
require_once("include/function.php");

$member = new member();
