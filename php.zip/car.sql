-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- 主機: localhost
-- 建立日期: 2017 年 06 月 24 日 01:51
-- 伺服器版本: 5.5.53-0ubuntu0.14.04.1
-- PHP 版本: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 資料庫: `car`
--

-- --------------------------------------------------------

--
-- 資料表結構 `car`
--

CREATE TABLE IF NOT EXISTS `car` (
  `ID` int(3) NOT NULL,
  `offer_ID` varchar(255) DEFAULT NULL,
  `brand` varchar(10) DEFAULT NULL,
  `seat` varchar(2) DEFAULT NULL,
  `year` int(2) DEFAULT NULL,
  `remark` text,
  PRIMARY KEY (`ID`),
  KEY `NO` (`ID`),
  KEY `brand` (`brand`),
  KEY `offer_ID` (`offer_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `car`
--

INSERT INTO `car` (`ID`, `offer_ID`, `brand`, `seat`, `year`, `remark`) VALUES
(186, 'a1043317', 'mitsubishi', '7', 2, ''),
(192, 'a1043317', 'mitsubishi', '7', 3, ''),
(193, 'root', 'volkswagen', '5', 1, ''),
(194, 'root', 'mitsubishi', '5', 5, ''),
(196, 'a1043317', 'hyundai', '7', 4, ''),
(197, 'a1043317', 'volkswagen', '7', 10, ''),
(198, 'asdf', 'volkswagen', '5', 1, ''),
(199, 'asdf', 'volkswagen', '5', 3, ''),
(205, 'root', 'toyota', '7', 4, ''),
(206, 'root', 'volkswagen', '7', 4, NULL),
(207, 'root', 'mitsubishi', '7', 5, NULL),
(208, 'root', 'mitsubishi', '7', 5, NULL),
(209, 'root', 'toyota', '7', 4, NULL),
(243, 'a1043317', 'toyota', '7', 3, NULL),
(244, 'a1043317', 'toyota', '7', 7, NULL),
(245, 'a1043317', 'toyota', '7', 4, NULL),
(246, 'a1043317', 'toyota', '7', 4, NULL),
(247, 'a1043317', 'hyundai', '7', 4, ''),
(248, 'a1043317', 'hyundai', '7', 3, ''),
(250, 'root', 'mitsubishi', '5', 9, NULL),
(251, 'root', 'volkswagen', '5', 3, ''),
(253, 'root', 'volkswagen', '5', 1, '');

-- --------------------------------------------------------

--
-- 資料表結構 `orderr`
--

CREATE TABLE IF NOT EXISTS `orderr` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `car_ID` int(3) DEFAULT NULL,
  `rent_ID` varchar(255) DEFAULT NULL,
  `offer_ID` varchar(255) DEFAULT NULL,
  `seat` int(1) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `price` int(4) DEFAULT NULL,
  `pay` varchar(15) DEFAULT NULL,
  `pay_detail` text,
  `days` int(2) DEFAULT NULL,
  `remark` text,
  `month` int(2) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `rent_ID` (`rent_ID`),
  KEY `rent_ID_2` (`rent_ID`),
  KEY `offer_ID` (`offer_ID`),
  KEY `rent_ID_3` (`rent_ID`),
  KEY `car_ID` (`car_ID`),
  KEY `car_ID_2` (`car_ID`),
  KEY `car_ID_3` (`car_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=197 ;

--
-- 資料表的匯出資料 `orderr`
--

INSERT INTO `orderr` (`ID`, `car_ID`, `rent_ID`, `offer_ID`, `seat`, `start_date`, `start_time`, `end_date`, `end_time`, `price`, `pay`, `pay_detail`, `days`, `remark`, `month`) VALUES
(163, 243, 'a1043317', 'a1043317', 7, '2017-06-15', '00:00:00', '2017-06-22', '00:00:00', 900, 'ATM,meeting', 'meeting', 1, '', 6),
(164, NULL, 'a1043352', NULL, 5, '2017-06-08', '22:01:00', '2017-07-06', '01:59:00', 810, 'meeting', NULL, 29, '', 6),
(166, 246, 'qwer', 'a1043317', 7, '2017-07-04', '00:59:00', '2017-07-06', '00:00:00', 500, 'meeting', 'meeting', 3, '', 7),
(169, NULL, 'zxcv', NULL, 5, '2017-06-08', '00:00:00', '2017-06-14', '00:00:00', 1250, 'meeting', NULL, 1, '', 6),
(170, 192, 'root', 'a1043317', 7, '2017-06-16', '00:00:00', '2017-06-28', '00:00:00', 123, 'ATM meeting', 'meeting', 13, '', 6),
(171, 193, 'root', 'root', 5, '2017-06-08', '00:00:00', '2017-06-09', '00:00:00', 50, 'ATM meeting', 'meeting', 2, '', 6),
(172, 250, 'root', 'root', 5, '2017-06-08', '12:59:00', '2017-06-09', '12:59:00', 50, 'ATM,meeting', 'meeting', 2, 'popo', 6),
(173, 194, 'qwer', 'root', 5, '2017-06-13', '00:00:00', '2017-06-15', '00:00:00', 500, 'meeting', 'meeting', 3, '', 6),
(175, 245, 'qwer', 'a1043317', 7, '2017-06-15', '00:00:00', '2017-06-29', '00:00:00', 810, 'meeting', 'meeting', 1, '', 6),
(176, 196, 'root', 'a1043317', 7, '2017-06-15', '00:00:00', '2017-06-16', '00:00:00', 1000, 'meeting', 'meeting', 2, '', 6),
(177, 197, 'zedd', 'a1043317', 7, '2017-06-10', '00:00:00', '2017-06-11', '00:00:00', 400, 'ATM', '123+123123', 2, '', 6),
(178, 198, 'root', 'asdf', 5, '2017-06-08', '13:00:00', '2017-06-13', '01:00:00', 1000, 'meeting', 'meeting', 6, '', 6),
(179, 199, 'root', 'asdf', 5, '2017-06-14', '01:00:00', '2017-06-21', '01:00:00', 200, 'ATM', '', 8, '', 6),
(180, NULL, 'a1043317', NULL, 7, '2017-06-14', '13:00:00', '2017-06-21', '01:00:00', 500, 'meeting', NULL, 8, '', 6),
(182, 244, 'a1043317', 'a1043317', 7, '2017-06-13', '01:01:00', '2017-06-22', '01:00:00', 400, 'ATM', '123+123123123', 10, '', 6),
(183, 205, 'a1043317', 'root', 7, '2017-06-14', '13:00:00', '2017-06-21', '01:00:00', 100, 'meeting', 'meeting', 8, '', 6),
(185, 247, 'a1043317', 'a1043317', 7, '2017-06-21', '01:00:00', '2017-06-28', '13:00:00', 500, 'ATM meeting', '456+123456', 8, '', 6),
(186, NULL, 'a1043317', NULL, 7, '2017-07-07', '01:00:00', '2017-07-13', '01:00:00', 500, 'ATM,meeting', NULL, 7, '', 7),
(187, NULL, 'a1043317', NULL, 7, '2017-07-04', '01:00:00', '2017-07-07', '01:00:00', 1000, 'meeting', NULL, 4, '', 7),
(188, NULL, 'a1043317', NULL, 5, '2017-07-11', '01:00:00', '2017-07-12', '01:00:00', 600, 'ATM,meeting', NULL, 2, '', 7),
(189, NULL, 'a1043317', NULL, 5, '2017-07-11', '01:00:00', '2017-07-12', '01:00:00', 600, 'ATM,meeting', NULL, 2, '', 7),
(190, NULL, 'a1043317', NULL, 5, '2017-07-11', '01:00:00', '2017-07-12', '01:00:00', 600, 'ATM,meeting', NULL, 2, '', 7),
(191, NULL, 'a1043317', NULL, 5, '2017-07-11', '01:00:00', '2017-07-12', '01:00:00', 600, 'ATM,meeting', NULL, 2, '', 7),
(192, 248, 'a1043317', 'a1043317', 7, '2017-06-21', '01:00:00', '2017-07-06', '01:00:00', 400, 'meeting', 'meeting', 16, '', 6),
(193, NULL, 'henry', NULL, 5, '2017-11-16', '01:00:00', '2017-11-17', '01:00:00', 6790, 'meeting', 'meeting', 2, NULL, 11),
(194, 251, NULL, 'root', 5, '2017-06-17', NULL, '2017-06-20', NULL, 150, 'meeting', 'meeting', 4, '', 6),
(196, 253, NULL, 'root', 5, '2017-06-22', NULL, '2017-06-27', NULL, 500, 'meeting', 'meeting', 6, '', 6);

-- --------------------------------------------------------

--
-- 資料表結構 `pm`
--

CREATE TABLE IF NOT EXISTS `pm` (
  `id` bigint(20) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `user1` varchar(255) NOT NULL,
  `user2` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `timestamp` int(10) NOT NULL,
  `user1read` varchar(3) NOT NULL,
  `user2read` varchar(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `user1` (`user1`),
  KEY `user2` (`user2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `pm`
--

INSERT INTO `pm` (`id`, `id2`, `title`, `user1`, `user2`, `message`, `timestamp`, `user1read`, `user2read`) VALUES
(1, 1, 'qwerqwe', 'a1043311', 'zed', 'asdfghjkl', 1496424169, 'yes', 'yes'),
(2, 1, 'qazwsx', 'a1043311', 'zed', 'erqtiuoo;,mnb', 1496486065, 'yes', 'yes'),
(3, 1, 'qazwsx', 'a1043311', 'zed', 'erqtiuoo;,mnb', 1496486083, 'yes', 'yes'),
(4, 1, 'kjhgdfds', 'zed', 'a1043311', ',jmcnvbcxz', 1496486557, 'yes', 'yes'),
(5, 1, 'how are you', 'a1043311', 'zed', 'hello', 1496487107, 'yes', 'yes'),
(6, 1, 'im fine', 'zed', 'a1043311', 'hihi', 1496508426, 'yes', 'yes'),
(7, 1, 'ok', 'zed', 'a1043311', 'okok', 1496508657, 'yes', 'yes'),
(8, 1, '?', 'zed', 'a1043311', '?', 1496509695, 'yes', 'yes'),
(9, 1, 'what', 'a1043311', 'zed', '?', 1496509765, 'yes', 'yes'),
(10, 1, '?', 'zed', 'a1043311', '????', 1496509803, 'yes', 'no'),
(11, 1, 'hi im root', 'root', 'qwer', 'im root', 1496565010, 'yes', 'yes'),
(12, 1, 'hi im root', 'qwer', 'root', 'so?', 1496565055, 'yes', 'yes'),
(13, 1, 'TEST', 'qwer', 'root', 'ZZZZZ', 1496653798, 'yes', 'yes'),
(14, 1, 'xxx', 'qwer', 'root', 'GG', 1496654196, 'yes', 'yes'),
(15, 1, 'zzz', 'qwer', 'root', 'bbbb', 1496654223, 'yes', 'yes'),
(16, 1, '666666666', 'qwer', 'root', '?', 1496656233, 'yes', 'yes'),
(17, 1, 'æ‰¾é£¯åº—?', 'qwer', 'root', 'Trivagoooooooooooooooooooo', 1496656314, 'yes', 'yes'),
(18, 1, '123', 'henry', 'a1043317', 'sdfsdfsdfsdfdsfdf', 1496737322, 'yes', 'yes'),
(19, 1, 'hihi', 'asdf', 'qwer', 'hihi', 1496812489, 'yes', 'no'),
(20, 1, 'qwer', 'root', 'a1043317', 'SFDAGHJFK', 1496812541, 'yes', 'no'),
(21, 1, '123', 'a1043317', 'root', '12312313', 1496812543, 'yes', 'yes'),
(22, 1, '???', 'root', 'a1043317', 'jo4cl4<br />\r\n', 1496812595, 'yes', 'no'),
(23, 1, 'å®‰å®‰', 'root', 'a1043317', 'å¯„çµ¦ä½ äº†', 1496814345, 'yes', 'no'),
(24, 1, '123', 'a1043317', 'root', '12312313', 1496816141, 'yes', 'yes');

-- --------------------------------------------------------

--
-- 資料表結構 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 NOT NULL,
  `userphone` varchar(10) CHARACTER SET utf8 NOT NULL,
  `grade` text COLLATE utf8_unicode_ci NOT NULL,
  `bank` int(3) NOT NULL,
  `bankaccount` text CHARACTER SET utf8 NOT NULL,
  `level` char(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=79 ;

--
-- 資料表的匯出資料 `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `userphone`, `grade`, `bank`, `bankaccount`, `level`) VALUES
(56, 'a1043317', 'a@gmail.com', '7db2c888377a1bb5618782e447ee4a82', '0915086000', '107', 0, '', 'admin'),
(70, 'a1043352', 'whatallpassme@gmail.com', '45b2906c4aa9f7773503ec3e5de32825', '0978582190', '106', 0, '', 'user'),
(71, 'A10444', 'A101010@GMAIL.COM', 'bcd7e1296602834d10ebb6a9b8ca1684', '0989877778', '108', 0, '', 'user'),
(67, 'AllPass', 'whatseec@gmail.com', '481701fa4093499eacd05b57bebc7ffc', '0999999858', '108', 0, '', 'user'),
(75, 'asdf', 'asdf@gmail.com', '912ec803b2ce49e4a541068d495ab570', '0987888745', '108', 0, '', 'user'),
(61, 'henry', '123@gmail.com', '027e4180beedb29744413a7ea6b84a42', '0915086000', '108', 0, '', 'user'),
(65, 'hiniho', 'whatwhat@gmail.com', '9e23cf1c143525bef9b6b2422417cea9', '0985122541', '108', 0, '', 'user'),
(69, 'howahll', 'howhow@gmail.com', '6f51c6cf1ac3c4dfde1f07d0b981a02e', '0974112111', '108', 0, '', 'user'),
(64, 'howareyou', 'hello@gmail.com', '5d41402abc4b2a76b9719d911017c592', '0985748596', '108', 0, '', 'user'),
(66, 'mulPHPallPass', 'AllPass@gmail.com', '0461def9332bb3ff33e5d9e9a9d883c2', '0985587777', '108', 0, '', 'user'),
(57, 'nukim', 'test@gmail.com', 'c3b6cb4b411a03dc0cd21b6ec204a69a', '0911111111', '108', 0, '', 'user'),
(58, 'nukom', 'testt@gmail.com', '64b460df8ba4143a433b3db31ee04d34', '0922222222', '107', 0, '', 'user'),
(59, 'nukpm', 'testtt@gmail.com', 'df2ec26415f6b0a6953285d7d6fe9637', '0933333333', '107', 0, '', 'user'),
(77, 'qazwsx', 'qazwsc@yahoo.com', '76419c58730d9f35de7ac538c2fd6737', '0966666666', '107', 0, '', 'user'),
(54, 'qazz', 'lollinlol777@gmail.com', '4eae18cf9e54a0f62b44176d074cbe2f', '0972176499', '106', 0, '', 'user'),
(62, 'qw12', 'qw12@gmail.com', '68faffc68e1c53942d47ada2627cca0f', '0972316488', '106', 145, '123456654321', 'user'),
(53, 'qwer', 'v85112@yahoo.com', '962012d09b8170d912f0669f6d7d9d07', '0966666666', '109', 145, '123123321321', 'user'),
(52, 'root', '123@yahoo.com', 'ae96fb8bd98436d573396b5a8972a8b7', '0972176499', '109', 124, '111222333444', 'admin'),
(60, 'test123', '1@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '0988888888', '108', 800, '2345678765432', 'user'),
(73, 'UcMeCu', 'wdwdwds@gmail.com', 'ce6ba5e12fd36983aaaebf4ba8f37abc', '0989969698', '108', 0, '', 'user'),
(63, 'what', 'what@gmail.com.tw', '4a2028eceac5e1f4d252ea13c71ecec6', '0974125896', '108', 0, '', 'user'),
(68, 'whatcme', 'dontcme@gmail.com', 'fde15c12835336b2243908f140d56c93', '0988588869', '108', 0, '', 'user'),
(78, 'zedd', 'v85112@yahoo.com', 'dc693143c7eb8dfe1f867164dfa662d1', '0972176499', '108', 0, '', 'user'),
(76, 'zxcv', 'zxcv@gmail.com', 'fd2cc6c54239c40495a0d3a93b6380eb', '0955555555', '108', 0, '', 'user');

--
-- 已匯出資料表的限制(Constraint)
--

--
-- 資料表的 Constraints `car`
--
ALTER TABLE `car`
  ADD CONSTRAINT `car_ibfk_1` FOREIGN KEY (`offer_ID`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 資料表的 Constraints `orderr`
--
ALTER TABLE `orderr`
  ADD CONSTRAINT `orderr_ibfk_1` FOREIGN KEY (`rent_ID`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderr_ibfk_2` FOREIGN KEY (`offer_ID`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderr_ibfk_3` FOREIGN KEY (`car_ID`) REFERENCES `car` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
